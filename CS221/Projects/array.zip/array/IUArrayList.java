  import java.util.Arrays;
  import java.util.ConcurrentModificationException;
  import java.util.Iterator;
  import java.util.ListIterator;
  import java.util.NoSuchElementException;

  /*
  * @author Irene Galca
  * @param <T>
  */
  public class IUArrayList<T> implements IndexedUnsortedList<T> {
	  private static final int DEFAULT_CAPACITY=50;
	  private T[] list; //list that holds objects
	  private int count; //number of elements in the list
	  private int modCount; //modified count of list
	  private boolean removeable;

	  /*
	  * Creates an empty list with an initial capacity
	  */
	  public IUArrayList() {
		  this(DEFAULT_CAPACITY);
	  }
	  /*
	  * Creates and empty list with the given inital capacity
	  * @param initialCapacity
	  */
	  @SuppressWarnings("unchecked")
	  public IUArrayList(int initialCapacity) {
		  list=(T[])(new Object[initialCapacity]);
		  count=0;
		  modCount=0;
	  }

	  /*
	  * Doubles the capacity of the list
	  */
	  private void expand() {
		  list=Arrays.copyOf(list,  list.length*2);
	  }

	  /*
	  * Adds to the front of the list.
	  * @param T element
	  */
	  @Override
	  public void addToFront(T element) {
		  add(0, element);
	  }

	  /*
	  * Adds to the back of the list.
	  * @param T element
	  */
	  @Override
	  public void addToRear(T element) {
		  add(count, element);
	  }

	  /*
	  * Adds to the back of the list
	  * @param T element
	  */
	  @Override
	  public void add(T element) {
		  add(count, element);
	  }
	  
	  /*
	  *Adds element after a specified target
	  *@param T element
	  *@param T target
	  *@throws NoSuchElementException if target is not found in the list.
	  */  
	  @Override
	  public void addAfter(T element, T target) {
		  // TODO Auto-generated method stub
		  //
		  if (list.length == count) {
			  expand();
		  }
		  int index = -1;
		  for (int i = 0; i < count; i++) {
			  if (list[i].equals(target)) {
				  index = i;
				  break;
			  }
		  }
		  if (index == -1) {
			  throw new NoSuchElementException("IUlistList - addAfter");
		  }
		  for (int i = count - 1; i > index; i--) {
			  list[i + 1] = list[i];
		  }
		  list[index + 1] = element;
		  count++;
		  modCount++;
	  }
	  
	  /*
	  *Adds element at a specified index.
	  *@param int index //index where element is to be inserted
	  *@param T element
	  *@throws IndexOutOfBoundsException //if the index is out of range.
	  */
	  @Override
	  public void add(int index, T element) {
		  // TODO Auto-generated method stub
		  if(index < 0 || index > count) {
			  throw new IndexOutOfBoundsException("IUlistList - add(int index, T element");
		  }
		  if(DEFAULT_CAPACITY==count) {
			  expand();
		  }
		  for(int i = count; i > index; i--) {
			  list[i]=list[i-1];
		  }
		  list[index]= element;
		  count++;
		  modCount++;
	  }
	  
	  /*
	  *Removes first element in the list
	  *@return removedElement //returns the element we removed
	  *@throws NoSuchElementException if list has no elements.
	  */
	  @Override
	  public T removeFirst() {
		  // TODO Auto-generated method stub
		  if(isEmpty()) {
			  throw new NoSuchElementException("IUArrayList - removeFirst()");
		  }
		  T removedElement= list[0];
		  for(int i=0; i<count-1; i++) {
			  list[i]=list[i+1];
		  }
		  list[count-1]= null;
		  count--;
		  return removedElement;
	  }

	  /*
	  *Removes the last elementfrom the list.
	  *@return removedElement //returns element removed
	  *@throws NoSuchElementException if list contains no elements.
	  */
	  @Override
	  public T removeLast() {
		  // TODO Auto-generated method stub
		  if(isEmpty()) {
			  throw new NoSuchElementException("IUArrayList - removeLast()");
		  }
		  T removedElement= list[count-1];
		  count--;
		  return removedElement;
	  }

	  /*
	  *Removes the specified element from the list.
	  *@param T element //element to be removed.
	  *@return removedElement //returns removed element.
	  *@throws NoSuchElementException if element is not in the list.
	  */
	  @Override
	  public T remove(T element) {
		  // TODO Auto-generated method stub
		  int index = indexOf(element);
		  if (index == -1) {
			  throw new NoSuchElementException();
		  }
		  T removedElement = list[index];
		  count--;
		  // shift elements
		  for (int i = index; i < count; i++) {
			  list[i] = list[i + 1];
		  }
		  list[count] = null;
		  modCount++;
		  return removedElement;

	  }

	  /*
	  *Removes and returns element at specified index.
	  *@param int index //the specified index
	  *@return removedElement //returns element removed at specified index
	  *@throws IndexOutOfBoundsException if the index is out of range.
	  */
	  @Override
	  public T remove(int index) {
		  // TODO Auto-generated method stub
		  if (index < 0 || index > size() - 1) {
			  throw new IndexOutOfBoundsException("IUArrayList - remove");
		  }
		  T removedElement = list[index];
		  for (int i = index; i < count - 1; i++) {
			  list[i] = list[i + 1];
		  }
		  list[count - 1] = null;
		  count--;
		  modCount++;
		  return removedElement;
	  }

	  /*
	  *Sets the element at specified index.
	  *@param int index //index where the the element is to be set
	  *@param T element //element to be set
	  *@throws IndexOutOfBoundsException if the idex is out of range.
	  */
	  @Override
	  public void set(int index, T element) {
		  // TODO Auto-generated method stub
		  if (index < 0 || index > size() - 1) {
			  throw new IndexOutOfBoundsException("IUArrayList - set");
		  }
		  list[index] = element;
		  modCount++;

	  }

	  /*
	  *Returns a reference to the element at the specified index.
	  *@param int index //index where reference is to be retrieved from
	  *@return list[index] //returns element retrived from specified index
	  *@throws IndexOutOfBoundsException if the index is out of range
	  */
	  @Override
	  public T get(int index) {
		  // TODO Auto-generated method stub
		  if (index < 0 || index > size() - 1) {
			  throw new IndexOutOfBoundsException("IUArrayList - get");
		  }
		  return list[index];
	  }

	  /*
	  *Returns the index of a specified element.
	  *@param T element //The element to be retrieved from said index
	  *@return index //the index where the element is located
	  */
	  @Override
	  public int indexOf(T element) {
		  // TODO Auto-generated method stub
		  int index= -1;
		  if(!isEmpty()) {
			  int i=0;
			  while(index== -1 && i<count) {
				  if(element.equals(list[i])) {
					  index=i;
				  }else {
					  i++;
				  }
			  }
		  }
		  return index;
	  }

	  /*
	  *Returns reference to the first element in the list
	  *@return list[0] //returns the element at the first index.
	  *@throws NoSuchElementException if list contains no elements
	  */
	  @Override
	  public T first() {
		  // TODO Auto-generated method stub
		  if (isEmpty()) {
			  throw new NoSuchElementException("IUArrayList - First");
		  }
		  return list[0];
	  }

	  /*
	  *Returns a reference to the last element of the list
	  *@return list[count-1] // returns element at the last index of the list
	  *@throws NoSuchElementException if list contains no elements
	  */
	  @Override
	  public T last() {
		  // TODO Auto-generated method stub
		  if (isEmpty()) {
			  throw new NoSuchElementException("IUArrayList - last");
		  }
		  return list[count - 1];
	  }

	  /*
	  *Returns true if the list contains the specified target element
	  *@param T target //the target that is being searched for in the list
	  *@return (indexOf(target) != -1) //returns true if it contains the element, returns false otherwise
	  */
	  @Override
	  public boolean contains(T target) {
		  // TODO Auto-generated method stub
		  return (indexOf(target) != -1);
	  }

	  /*
	  *Returns true if list is empty
	  *@return true if list is empty, returns false otherwise
	  */
	  @Override
	  public boolean isEmpty() {
		  // TODO Auto-generated method stub
		  if (count == 0)
			  return true;
		  else
			  return false;
	  }

	  /*
	  *Returns number of elements in list
	  *@return count //number of elements in list
	  */
	  @Override
	  public int size() {
		  // TODO Auto-generated method stub
		  return count;
	  }

	  /*
	  *Returns an iterator for the elements in the list.
	  *@return iterator of the elements in the list
	  */
	  @Override
	  public Iterator<T> iterator() {
		  // TODO Auto-generated method stub
		  modCount++;
		  return new ALIterator();

	  }

	  /*
	  *Returns a ListIterator fpr the elements in the list
	  *@throws UnsupportedOperationException if not implemented
	  */
	  @Override
	  public ListIterator<T> listIterator() {
		  // TODO Auto-generated method stub
		  throw new UnsupportedOperationException();
	  }

	  /*
	  *Returns listiterator for the elements in the list
	  *with the iterator positioned before the specified index
	  *@throws UnsupportedOperationException if not implemented
	  */
	  @Override
	  public ListIterator<T> listIterator(int startingIndex) {
		  // TODO Auto-generated method stub
		  throw new UnsupportedOperationException();
	  }
	  private class ALIterator implements Iterator<T> {
		  private int nextIndex;
		  private int iterModCount;
		  public ALIterator() {
			  nextIndex = 0;// index of item in list 
			  iterModCount = modCount;
			  removeable = false;
		  }

		  @Override
		  public boolean hasNext() {
			  // TODO Auto-generated method stub
			  checkModCount();
			  return nextIndex < count;

		  }

		  /*
		  *Checks the modified number of elements in the list.
		  *@throws CocurrentModificationException if modCountis not equivalent
		  */
		  private void checkModCount() {
			  // TODO Auto-generated method stub
			  if (iterModCount!=modCount) {
				  throw new ConcurrentModificationException("ListIterator -checkModCount");
			  }

		  }

		  /*
		  *Goes to the next element/index in the list.
		  *@returns the element at specified index
		  *@throws NoSuchElementException if element doesn't exist at said index
		  */
		  @Override
		  public T next() {
			  // TODO Auto-generated method stub
			  T temp = null;
			  if (hasNext()) {// after it calls it once it will go to the next position
				  temp = list[nextIndex];
				  nextIndex++;
				  removeable = true;
			  } else {
				  throw new NoSuchElementException("ListIterator - next");
			  }
			  return temp;
		  }
		  public void remove() {
			  //
			  checkModCount();
			  if (removeable) {
				  for (int i = nextIndex - 1; i < count - 1; i++) {
					  list[i] = list[i + 1];
				  }
				  list[count - 1] = null;// if element is not in list
				  count--;
				  nextIndex--;
				  removeable = false;// cannot remove 
			  } else {
				  throw new IllegalStateException(" ListItterator - remove");

			  }
		  }
	  }
  }
